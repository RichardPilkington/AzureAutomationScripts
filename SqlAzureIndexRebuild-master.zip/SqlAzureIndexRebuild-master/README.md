# SqlAzureIndexRebuild
Azure Function to rebuild all SQL Azure Databases on a SQL Azure Service
